package drivers.samsung;

public enum PrinterLevel {
    WORRIES, LOW, BELOW_HALF, HALF, OVER_HALF, HIGH, NO_WORRIES
}

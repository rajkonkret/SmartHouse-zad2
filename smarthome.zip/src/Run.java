import sun.dc.pr.PRError;

public class Run {
    //    Napisać aplikację obsługującą drukarki w domu.
//    Każda drukarka powinna mieć możliwość wydruku* dowolnego tekstu poprzedzonego nazwą drukarki.
//    Użytkownik dostępne ma następujące funkcje w SmartHouse:
//    a)wydrukuj na drukarce o podanej nazwie
//        b)wydrukuj na wszystkich drukarkach
//        c)sprawdź poziom tuszu (empty, low, medium, high, full)
//    Rozwinięcia:Zwizualizować na konsoli ten pięciostopniowy poziom tuszu
//            (sposób wizualizacji pozostawiam uczestnikom)
    public static void main(String[] args) {
        Printer salon = new Printer(InkIndicator.FULL, "SALON");
        System.out.println(salon.toPrint());
        System.out.println(salon.printDocument("Radek jest kochany"));

    }
}

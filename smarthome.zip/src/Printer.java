public class Printer {
    private InkIndicator inkIndicator;
    private String name;

    public Printer(InkIndicator inkIndicator, String name) {
        this.inkIndicator = inkIndicator;
        this.name = name;
    }

    String printDocument(String doc) {
        return name + " " + doc;
    }

    String toPrint() {
        return "Drukarka: " + name + " poziom tuszu " + inkIndicator.getNice();
    }

    InkIndicator getInkIndicator() {
        return inkIndicator;
    }

}
